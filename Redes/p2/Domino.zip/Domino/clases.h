#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>



////////////////////////////////////////////////////////////////////////////

// Estructura para las posiciones de las fichas
struct ficha
{
	int izq;
	int der;
};

// Estructura para los clientes
struct clients
{
	char user[40];
	char pass[40];
	int nivel;
	int mesa;
	struct ficha fichas[8];	//?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿¿¿?¿¿?¿¿?¿¿?¿¿¿?¿?¿?¿?¿?¿?¿	
	int nFichas;
	int socket;
	int id;
};

// Estrutura para la partida
struct partida
{
	int numpartida;
	char tablero[200];
	int izquierda;
	int derecha;
	int usuarios[2];
	struct ficha fichas[29];
	int turno;
	int start; //varible de control
	int pasar;
};

////////////////////////////////////////////////////////////////////////////

void iniciarDomino(struct partida n, struct clients *clientes);	// Inicia la partida de DOMINÓ con los jugadores
bool ponerFicha(struct partida *n, struct ficha k, int nMesa);	// Pone la ficha seleccionada en la mesa
void quitarFicha(struct clients *c, struct ficha f, int n);		// Quita la ficha seleccionada de la mano
void verFichas(struct clients *c, int n);						// Enseña las fichas del cliente?¿?¿?¿?¿?¿¿?¿¿?¿?¿¿¿?¿?¿?¿?¿?¿?¿?¿?

////////////////////////////////////////////////////////////////////////////

void iniciarDomino(struct partida n, struct clients *clientes)
{
	int i, j, k, h;
	h = 0;
	k = 0;
	
	for(i = 0; i < 7; i++)
	{
		for(j = 6; j >= h; j--)
		{
			(n.fichas[k]).izq = i;
			(n.fichas[k]).der = j;
			//printf("ficha %d : |%d|%d|\n",h,i,j);
			k++;
		}
	h++;
	}
	
	srand(time(NULL));
	j = 0;

	for(i = 0; i < 7; i++)
	{
		k = rand() % 4;

		(clientes[k % 4]).fichas[i] = n.fichas[j];
		j++;

		(clientes[(k + 1) % 4]).fichas[i] = n.fichas[j];
		j++;
/*
		(clientes[(k + 2) % 4]).fichas[i] = n.fichas[j];
		j++;

		(clientes[(k + 3) % 4]).fichas[i] = n.fichas[j];
		j++;
*/
	}
	
	clientes[0].nFichas = 7;
	clientes[1].nFichas = 7;
//	clientes[2].nFichas = 7;
//	clientes[3].nFichas = 7;
}

////////////////////////////////////////////////////////////////////////////

bool ponerFicha(struct partida *n, struct ficha k, int nMesa)
{
	int i, j;
	char aux[200];
	char aux2[10];
	strcpy(aux, n[nMesa].tablero);
	//printf("\n-->>>>>>>>>><PONIENDO FICHAAA\n");

	if((k.izq == 6) && (k.der == 6))
	{
		//printf("\nPrimera mano\n");
		n[nMesa].start = 1;
		strcpy(n[nMesa].tablero, "");
		sprintf(n[nMesa].tablero, "|%d|%d|", k.der, k.izq);
		
		n[nMesa].derecha = k.der;
		n[nMesa].izquierda = k.izq;
		
		printf("\nTABLERO\n%s\n", n[nMesa].tablero);
		
		return true;
	}
	else
	{
		//printf("\nOtra mano\n");
		//printf("\nIzquierda: %d\n", n[nMesa].izquierda);
		//printf("\nDerecha: %d\n", n[nMesa].derecha);
		//printf("Ficha: | %d | %d | \n",k.izq, k.der);
		if(n[nMesa].izquierda == k.izq)
		{
			strcpy(n[nMesa].tablero, "");
			sprintf(n[nMesa].tablero, "|%d|%d|", k.der, k.izq);
			sprintf(n[nMesa].tablero, "%s%s",n[nMesa].tablero, aux);

			n[nMesa].izquierda=k.der;
			
			printf("\nTABLERO\n%s\n", n[nMesa].tablero);
	
			return true;
		}
		else if (n[nMesa].izquierda == k.der)
		{
			strcpy(n[nMesa].tablero, "");
			sprintf(n[nMesa].tablero, "|%d|%d|", k.izq, k.der);
			sprintf(n[nMesa].tablero, "%s%s",n[nMesa].tablero, aux);

			n[nMesa].izquierda = k.izq;
			
			printf("\nTABLERO\n%s\n", n[nMesa].tablero);
	
			return true;
		}
		else if(n[nMesa].derecha==k.izq)
		{

			sprintf(aux2, "|%d|%d|", k.izq, k.der);
			sprintf(n[nMesa].tablero, "%s%s",n[nMesa].tablero, aux2);

			n[nMesa].derecha = k.der;
			
			printf("\nTABLERO\n%s\n", n[nMesa].tablero);
	
			return true;
		}
		else if (n[nMesa].derecha == k.der)
		{
			sprintf(aux2, "|%d|%d|", k.der, k.izq);
			sprintf(n[nMesa].tablero, "%s%s", n[nMesa].tablero, aux2);

			n[nMesa].derecha = k.izq;
			
			printf("\nTABLERO\n%s\n", n[nMesa].tablero);
	
			return true;
		}
		else
		{
			printf("\n-ERR\n\n");
			
			return false;
		}
	}
}

////////////////////////////////////////////////////////////////////////////

void quitarFicha(struct clients *c, struct ficha f, int n)
{
	//printf("\n-->>>>>>quitando FICHAAA\n");
	char cad[100];
	char aux[10];
	strcpy(aux,"");
	strcpy(cad, "");
	int i;

	for(i = 0; i < 7; i++)
		{
		if((f.izq == c[n].fichas[i].izq) && (f.der == c[n].fichas[i].der))
		{
			c[n].fichas[i].izq = -1;
			c[n].fichas[i].der = -1;
		}
		else
		{
			sprintf(aux, "|%d|%d| ", c[n].fichas[i].izq, c[n].fichas[i].der);
			strcat(cad, aux);
		}	
	}
	(c[n].nFichas)--;
}

////////////////////////////////////////////////////////////////////////////

void verFichas(struct clients *c, int n)
{
	char cad[100];
	char aux[10];
	strcpy(aux, "");
	strcpy(cad, "");
	int i;

	for(i = 0; i < 7; i++)
	{
		if((c[n].fichas[i].izq == -1) && (c[n].fichas[i].der == -1))
		{
		
			// ?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿??¿?¿?¿?¿?¿?¿?¿?¿?¿¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?¿?

		}
		else
		{
			sprintf(aux, "|%d|%d| ", c[n].fichas[i].izq, c[n].fichas[i].der);
			strcat(cad, aux);
		}
	}

	send(c[n].socket, cad, 100, 0);
}

////////////////////////////////////////////////////////////////////////////