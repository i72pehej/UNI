/**
 * Fichero funcionesInicio.js que contendrá todas las funciones usadas en funcionesInicio.js
 * @author Isabel María Ariza Velasco
 * @author Julen Perez Hernandez
*/
function getInicio(param){
    if(param=="invitado"){
        document.getElementById('conUsuario').style.display = 'none';
		document.getElementById('modoInvitado').style.display = 'block';
	}
}