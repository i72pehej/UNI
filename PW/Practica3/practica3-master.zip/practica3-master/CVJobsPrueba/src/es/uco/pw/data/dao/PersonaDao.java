package es.uco.pw.data.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import es.uco.pw.display.javabean.UsuarioBean;

public class PersonaDao extends ConexionDao {
	
	public ArrayList<UsuarioBean> listarPersonas(String tipoCV, String profesion) {
		Statement stmt = null; 
		ArrayList<UsuarioBean> result = new ArrayList<>();
		try {
			Connection con=getConnection();
			stmt = con.createStatement();
		    ResultSet rs = stmt.executeQuery("select correo, nombre, rama, experiencia_laboral, situacion_laboral from Registro where tipo_cv = '"+tipoCV+"' and profesion ='"+profesion+"'");
		    while (rs.next()) {
		    	String correo = rs.getString("correo");
		    	String nombre = rs.getString("nombre");
		    	String rama = rs.getString("rama");
		    	String experienciaLaboral= rs.getString("experiencia_laboral");
		    	String situacionLaboral = rs.getString("situacion_laboral");
		        UsuarioBean user = new UsuarioBean();
		        user.setCorreo(correo);
		        user.setNombre(nombre);
		        user.setRama(rama);
		        user.setExperienciaLaboral(experienciaLaboral);
		        user.setSituacionLaboral(situacionLaboral);
		        result.add(user);
		    }
		    if (stmt != null) 
		    	stmt.close(); 
		} catch (Exception e) {
			System.out.println(e);
		} 
		return result;
	}

}
